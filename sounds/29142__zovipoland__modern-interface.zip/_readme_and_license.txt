Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - ZoviPoland ( https://freesound.org/people/ZoviPoland/ )

You can find this pack online at: https://freesound.org/people/ZoviPoland/packs/29142/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 517722__zovipoland__popup-down-2.wav
    * url: https://freesound.org/s/517722/
    * license: Attribution
  * 517721__zovipoland__popup-up-2.wav
    * url: https://freesound.org/s/517721/
    * license: Attribution
  * 517720__zovipoland__popup-down.wav
    * url: https://freesound.org/s/517720/
    * license: Attribution
  * 517719__zovipoland__popup-up.wav
    * url: https://freesound.org/s/517719/
    * license: Attribution
  * 517718__zovipoland__litte-warning.wav
    * url: https://freesound.org/s/517718/
    * license: Attribution
  * 517717__zovipoland__plum-interface-sound.wav
    * url: https://freesound.org/s/517717/
    * license: Attribution
  * 517716__zovipoland__complete.wav
    * url: https://freesound.org/s/517716/
    * license: Attribution
  * 517715__zovipoland__denied.wav
    * url: https://freesound.org/s/517715/
    * license: Attribution
  * 517714__zovipoland__welcome.wav
    * url: https://freesound.org/s/517714/
    * license: Attribution
  * 517713__zovipoland__alert-1.wav
    * url: https://freesound.org/s/517713/
    * license: Attribution
  * 517712__zovipoland__alert-2.wav
    * url: https://freesound.org/s/517712/
    * license: Attribution
  * 517711__zovipoland__alert-3-long.wav
    * url: https://freesound.org/s/517711/
    * license: Attribution
  * 517710__zovipoland__are-you-shure.wav
    * url: https://freesound.org/s/517710/
    * license: Attribution
  * 517709__zovipoland__complete-2.wav
    * url: https://freesound.org/s/517709/
    * license: Attribution
  * 517708__zovipoland__complete.wav
    * url: https://freesound.org/s/517708/
    * license: Attribution
  * 517707__zovipoland__welcome-2.wav
    * url: https://freesound.org/s/517707/
    * license: Attribution


